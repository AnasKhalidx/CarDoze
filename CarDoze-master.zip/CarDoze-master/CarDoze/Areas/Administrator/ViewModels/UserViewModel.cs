﻿/*using CarDoze.Models;

namespace CarDoze.Areas.Administrator.ViewModels
{
    public class UserViewModel : BaseEntity
    {
        public int UserID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public ICollection<OrderViewModel> Orders { get; set; }
        public ICollection<WishlistViewModel> Wishlists { get; set; }
        public ICollection<CompareCarViewModel> CompareCars { get; set; }
        public ICollection<NotificationViewModel> Notifications { get; set; }
        public ICollection<ReviewViewModel> Reviews { get; set; }
    }
}
*/