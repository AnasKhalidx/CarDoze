﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CarDoze.Areas.Identity.Pages.Account
{
    public class ForgotPasswordConfirmationModel : PageModel
    {
        public void OnGet()
        {
            // Any necessary logic to execute when the page is accessed can be placed here.
            // Generally, this page just displays a static message, so no action is required.
        }
    }
}
