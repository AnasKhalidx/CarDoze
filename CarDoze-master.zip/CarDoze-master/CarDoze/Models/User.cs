﻿/*using Microsoft.AspNetCore.Identity;

namespace CarDoze.Models
{
    public class User: IdentityUser<int>
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
        public ICollection<Order> Orders { get; set; }
        public ICollection<Wishlist> Wishlists { get; set; }
        public ICollection<CompareCar> CompareCars { get; set; }
        public ICollection<Notification> Notifications { get; set; }
        public ICollection<Review> Reviews { get; set; }
    }
}
*/